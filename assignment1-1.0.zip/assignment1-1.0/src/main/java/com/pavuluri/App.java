package com.pavuluri;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Name:"+"Anusha Pavuluri" );
        System.out.println( "Villanova Id:" + "apavulur@villanova.edu & Slack User Name: Anusha Pavuluri");
        System.out.println("I am from India, born and brought there. My under graduation was in Information "
        		+ "Technology and I had couple of years of experience in Mainframes technology as a developer "
        		+ "and I am into Project Management based out of my interest. I have done couple of small "
        		+ "projects in Java Programming in under graduation and I had been used java scripting and "
        		+ "other java related tools as part of my project work in my previous organizations. "
        		+ "I was worked for Bank of America & Verizon back in India. Currently I am pursuing "
        		+ "my master�s at Villanova University.");
        System.out.println("Coming to the current content, Maven is new to me I can say, "
        		+ "i have heard about it but haven�t get a chance to work on it so it�s fascinating to dig into it more. "
        		+ "I like the way the content posted in our web link, it is basically simple and precise. Additionally, "
        		+ "i have gone through couple of more resources before I start with my assignment. So far it is good, and "
        		+ "I do not think that any change required for our classes as of now. The resources from course content and "
        		+ "Slack were helping me with the learning part.");
        
    }
}
